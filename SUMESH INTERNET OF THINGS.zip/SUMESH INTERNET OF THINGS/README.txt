1.Launch Index.php.
2.ledstatus.sql is the Imported SQl file(database sql queries).
3.Form  php file is save.php 
4.Respective Appliance status can be found from state.php
5.main.css is the css file used for styling the webpages.
6. .jpg,.jfif,.jpeg are respective images used in the webpage
7. Sumeshiot.dll.ino is the arduino sketch which uses SIM900A GSM/GPRS module for connection and arduino as microcontroller.


 