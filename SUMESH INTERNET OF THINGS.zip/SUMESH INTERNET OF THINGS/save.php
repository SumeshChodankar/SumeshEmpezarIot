<html>
<head>
        <meta http-equiv = "refresh" content="60">
        <link rel="stylesheet" href="main.css">
        
    </head>
<body>
<?php
/*
echo $_POST["red"]; 
echo $_POST["green"]; 
echo $_POST["blue"]; 
echo $_POST["fan"]; 
*/
$red = "OFF";
$green = "OFF";
$blue = "OFF";
$fan = "OFF";
$savedDoneR = "0";
$savedDoneG = "0";
$savedDoneB = "0";
$savedDoneF = "0";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ledstatus";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "UPDATE ledStatus SET State='" .$_POST["red"]."' WHERE Color= 'red'";
$sql1 = "UPDATE ledStatus SET State='" .$_POST["green"]."' WHERE Color= 'green'";
$sql2 = "UPDATE ledStatus SET State='" .$_POST["blue"]."' WHERE Color= 'blue'";
$sql3 = "UPDATE ledStatus SET State='" .$_POST["fan"]."' WHERE Color= 'fan'";

if($conn->query($sql) === TRUE)
{
 $savedDoneR = "1";
}
else 
{
echo $sql;
    echo "Error updating record: " . $conn->error;
 $savedDoneR = "0";
}
$conn->close();
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


if($conn->query($sql1) === TRUE)
{
 $savedDoneG = "1";
}
else
{
 $savedDoneG = "0";
}
$conn->close();
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if($conn->query($sql2) === TRUE)
{
 $savedDoneB = "1";
}
else
{
 $savedDoneB = "0";
}
$conn->close();

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


if($conn->query($sql3) === TRUE)
{
 $savedDoneF = "1";
}
else
{
 $savedDoneF = "0";
}
$conn->close();



if ($savedDoneB == "1" && $savedDoneG == "1" && $savedDoneR == "1" && $savedDoneF == "1") 

{
   // echo "Record updated successfully";
		 if($_POST["red"] == "1")
		{
		$red = "ON";
		}
		else
		{
		 $red = "OFF";
		}
		if($_POST["green"] == "1")
		{
		$green = "ON";
		}
		else
		{
		$green = "OFF";
		}
		if($_POST["blue"] == "1")
		{
		$blue = "ON";
		}
		else
		{
		$blue = "OFF";
		}

		if($_POST["fan"] == "1")
		{
		$fan = "ON";
		}
		else
		{
		$fan = "OFF";
		}

		echo "<h4>New Status</h4>";
		echo "<h5>RED : " .$red . "</h5>" ;
		echo "<h5>GREEN : " .$green . "</h5>" ;
		echo "<h5>BLUE : " .$blue . "</h5>" ;
		echo "<h5>FAN : " .$fan . "</h5>" ;
		
		

} 

?>
<meta http-equiv="refresh" content="3;url=index.php" />
</body>
</html>