
<?php
include_once('detail.php');


?>

<html>

    <head>
                <meta http-equiv = "refresh" content="60">
        <link rel="stylesheet" href="main.css">
    </head>
<body>

<div class="a">IOT</div>

<table class=  " tablet"  style="width:100%">
    <tr>
      <th></th>
      <th></th>

    </tr>
    <tr>
      <td align="center">  <div class="image-text">
       
      
        <a class="bedroom"href="bedroom.html"><img src="bedroomimage.jfif" alt="Snow" style="width:50%"></a> 
    
    </div></td>
      <td>
      <table align="center" border="0px" style="width:400px; line-height:10px">
<tr>
    <th colspan="4"><h7>DETAILS </h7></th>
</tr>
<t>
<th align="left"><u>ID</u></th>
<th align="left"><u>Appliance </u></th>
<th align="left"><u>State</u></th>
</t>
<?php

while($rows = $result -> fetch_assoc())
{

    ?>
    <tr> 
<td><?php echo $rows['ID'];?></td>
<td><?php echo $rows['Color'];?></td>
<td><?php echo $rows['State'];?></td>
</td>
    </tr>
    <?php
}
?>
</table>

      </td>
    















    </tr>
    <tr>
      <td align="center"> <div class="kitchenimage">
        <a href="bedroom.html"><img src="kitchenimage.jpeg" alt="Snow" style="width:50%"></a> 
    </div></td>
      
    
    
    
    
    
    
    
    
    <td>


    <table align="center" border="0px" style="width:400px; line-height:10px">
<tr>
    <th colspan="4"><h7>DETAILS </h7></th>
</tr>
<t>
<th align="left"><u>ID</u></th>
<th align="left"><u>Appliance </u></th>
<th align="left"><u>state</u></th>
</t>
<?php

while($rows = $result -> fetch_assoc())
{

    ?>
    <tr> 
<td><?php echo $rows['ID'];?></td>
<td><?php echo $rows['Color'];?></td>
<td><?php echo $rows['State'];?></td>
</td>
    </tr>
    <?php
}
?>
</table>



      </td>








    
    </tr>

    <tr>
        <td align="center">  <div class="hallimage">
            <a href="bedroom.html"><img src="hallimage.jpg" alt="Snow" style="width:50%"></a> 
        </div></td>







        <td>

        <table align="center" border="0px" style="width:400px; line-height:10px">
<tr>
    <th colspan="4"><h7>DETAILS </h7></th>
</tr>
<t>
<th align="left"><u>ID</u></th>
<th align="left"><u>Appliance </u></th>
<th align="left"><u>state</u></th>
</t>
<?php

while($rows = $result -> fetch_assoc())
{

    ?>
    <tr> 
<td><?php echo $rows['ID'];?></td>
<td><?php echo $rows['Color'];?></td>
<td><?php echo $rows['State'];?></td>
</td>
    </tr>
    <?php
}
?>
</table>
        
        </td>







      
      </tr>
  </table>



</form>
</body>
</html>
